
<?php $__env->startSection('content'); ?>
    <div id="app">
        <router-view></router-view>
    </div>
    <script src="<?php echo e(mix('/js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backpack::layouts.top_left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/cpanel-disk-a/martheet/public_html/resources/views/vue/index.blade.php ENDPATH**/ ?>