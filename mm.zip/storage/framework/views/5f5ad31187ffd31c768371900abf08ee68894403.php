<?php $__env->startSection('title'); ?>
    <?php echo e($produit->nom); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="breadcrumb-section">
    <h2 class="sr-only">Site Breadcrumb</h2>
    <div class="container">
        <div class="breadcrumb-contents">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(URL('/')); ?>">Accueil</a></li>
                    <?php $__currentLoopData = $lien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item=>$i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($item==$categorie->nom): ?>
                            <li class="breadcrumb-item"><a
                                        href="<?php echo e(route($i,['categorie'=>$categorie->code])); ?>"><?php echo e($item); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="breadcrumb-item"><a href="#"><?php echo e($item); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </nav>
        </div>
    </div>
</section>
<main class="inner-page-sec-padding-bottom">
    <div class="container">
        <div class="row  mb--60">
            <div class="col-lg-5 mb--30">
                <!-- Product Details Slider Big Image-->
                <div class="product-details-slider sb-slick-slider arrow-type-two" data-slick-setting='{
      "slidesToShow": 1,
      "arrows": false,
      "fade": true,
      "draggable": false,
      "swipe": false,
      "asNavFor": ".product-slider-nav"
      }'>
      <?php $liens=$produit->image; $lien=json_decode($liens); $img="img.jpg";
            if ($lien) { foreach($lien as $i){$img=$i;break;} }  ?>
             <?php $__currentLoopData = $lien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single-slide">
                        <img src="<?php echo e(asset('storage/'.$img)); ?>" alt="" height="400">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <!-- Product Details Slider Nav -->
                <div class="mt--30 product-slider-nav sb-slick-slider arrow-type-two" data-slick-setting='{
    "infinite":true,
      "autoplay": true,
      "autoplaySpeed": 8000,
      "slidesToShow": 4,
      "arrows": true,
      "prevArrow":{"buttonClass": "slick-prev","iconClass":"fa fa-chevron-left"},
      "nextArrow":{"buttonClass": "slick-next","iconClass":"fa fa-chevron-right"},
      "asNavFor": ".product-details-slider",
      "focusOnSelect": true
      }'>
      <?php $__currentLoopData = $lien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="single-slide">
        <img src="<?php echo e(asset('storage/'.$img)); ?>" alt="">
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
            <div class="col-lg-7">
                <?php $offre = \DB::table('offres')->where('code_produit',$produit->code)->first(); ?>
                <div class="product-details-info pl-lg--30 ">
                    
                    <h3 class="product-title"><?php echo e($produit->nom); ?></h3>

                    <?php if($offre && intval($offre->reduction)!=0): ?>

                    <p style="float:right;color:#EE00AA;border-bottom:2px solid #EE00AA;font-weight:bold">-<?php echo e($offre->reduction); ?>%</p> <?php endif; ?>
                    <ul class="list-unstyled">
                        <?php if($produit->auteur): ?> <li style="font-size:18px">Auteur : <a href="#" class="list-value font-weight-bold"> <?php echo e($produit->auteur); ?></a></li> <?php endif; ?>
                    </ul> <br>


                    <div class="price-block">
                        <span>prix : </span> <span class="price-new"><?php echo e($produit->prix_vente); ?> FCFA</span>
                        <!-- <del class="price-old"><?php echo e($produit->prix_achat); ?> FCFA</del> -->
                        <?php if($offre && intval($offre->reduction)!=0): ?><del class="price-old"><?php echo e($produit->prix_achat); ?> fcfa</del> <?php endif; ?>
                    </div>
                    <form id="form" action="<?php echo e(route('cart.store')); ?>" method="POST" style="border:none">
                        <?php echo csrf_field(); ?>

                    <div class="">
                        <input type="hidden" name="type_paye" id="type">
                        <?php
                            $prix_louer1= 3000;
                            $prix_louer2= 5000;
                        ?>
                        <div class="form-check">

                            <input type="radio" name="prix" id="acheter" checked value="<?php echo e($produit->prix_vente); ?>" onchange="change('achat')">
                            <label class="form-check-label" for="acheter">
                              Acheter
                            </label>
                          </div>
                          <div class="form-check">
                            <input type="radio" name="prix" id="louer" onchange="change('louer')">
                            <label class="form-check-label" for="louer">
                                Emprunter
                            </label>
                          </div>
                          <div class="form-check">
                              <br>
                              <span style="color:grey">avec l'abonnement mensuel vous avez la possibilité <br>d'emprunter un ou plusieurs livres par mois</span>

                          </div>

                          <!--<div class="form-check">-->
                          <!--  <input type="radio" name="prix" id="louer1" value="<?php echo e($prix_louer1); ?>" onchange="change('louer1')">-->
                          <!--  <label class="form-check-label" for="louer1">-->
                          <!--      Louer pour 15 jours à <?php echo e($prix_louer1); ?> f-->
                          <!--  </label>-->
                          <!--</div>-->
                          <!--<div class="form-check">-->
                          <!--  <input type="radio" name="prix" id="louer2" value="<?php echo e($prix_louer2); ?>" onchange="change('louer2')">-->
                          <!--  <label class="form-check-label" for="louer2">-->
                          <!--      Louer pour 1 mois à <?php echo e($prix_louer2); ?> f-->
                          <!--  </label>-->
                          <!--</div>-->


                    </div> <br>
                    <script>
                        function change(t){
                            document.getElementById('type').value =t;
                            // alert(t);
                        }
                    </script>
                    
                    

                    <div class="add-to-cart-row">
                        <div class="count-input-block">
                            <span class="widget-label">Qte</span>
                            <select class="form-control text-center"  id="qte" name="qte" style="background:#eee;border:solid 0px #000;border-radius:0%;">
                                <?php for($i = 1; $i <= $produit->quantite; $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                            
                        </div>
                        <div class="add-cart-btn">
                            <input type="hidden" name="code_produit" value="<?php echo e($produit->code); ?>">
                            <button type="submit" class="btn btn-outlined--primary">ajouter au panier</button>
                            
                        </div>

                    </div>
                    </form>
                    
                        
                    
                </div>
            </div>
        </div>
        <div class="sb-custom-tab review-tab section-padding">
            <ul class="nav nav-tabs nav-style-2" id="myTab2" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="tab1" data-toggle="tab" href="#tab-1" role="tab"
                        aria-controls="tab-1" aria-selected="true">
                        DESCRIPTION
                    </a>
                </li>
                
            </ul>
            <div class="tab-content space-db--20" id="myTabContent">
                <div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="tab1">
                    <article class="review-article">
                        <h1 class="sr-only">Tab Article</h1>
                        <span style="font-size: 50px"> <?php echo $produit->description; ?></span>
                    </article>
                </div>

                <div class="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="tab2">
                    <div class="review-wrapper">
                        <h2 class="title-lg mb--20">1 REVIEW FOR AUCTOR GRAVIDA ENIM</h2>
                        <div class="review-comment mb--20">
                            <div class="avatar">
                                <img src="image/icon/author-logo.png" alt="">
                            </div>
                            <div class="text">
                                <div class="rating-block mb--15">
                                    <span class="ion-android-star-outline star_on"></span>
                                    <span class="ion-android-star-outline star_on"></span>
                                    <span class="ion-android-star-outline star_on"></span>
                                    <span class="ion-android-star-outline"></span>
                                    <span class="ion-android-star-outline"></span>
                                </div>
                                <h6 class="author">ADMIN – <span class="font-weight-400">March 23, 2015</span>
                                </h6>
                                <p>Lorem et placerat vestibulum, metus nisi posuere nisl, in accumsan elit odio
                                    quis mi.</p>
                            </div>
                        </div>
                        <h2 class="title-lg mb--20 pt--15">ADD A REVIEW</h2>
                        <div class="rating-row pt-2">
                            <p class="d-block">Your Rating</p>
                            <span class="rating-widget-block">
                                <input type="radio" name="star" id="star1">
                                <label for="star1"></label>
                                <input type="radio" name="star" id="star2">
                                <label for="star2"></label>
                                <input type="radio" name="star" id="star3">
                                <label for="star3"></label>
                                <input type="radio" name="star" id="star4">
                                <label for="star4"></label>
                                <input type="radio" name="star" id="star5">
                                <label for="star5"></label>
                            </span>
                            <form action="./" class="mt--15 site-form ">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="message">Comment</label>
                                            <textarea name="message" id="message" cols="30" rows="10"
                                                class="form-control"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="name">Name *</label>
                                            <input type="text" id="name" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="email">Email *</label>
                                            <input type="text" id="email" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="website">Website</label>
                                            <input type="text" id="website" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="submit-btn">
                                            <a href="#" class="btn btn-black">Post Comment</a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!--=================================
RELATED PRODUCTS BOOKS
===================================== -->
    <section class="">
        <div class="container">
            <div class="section-title section-title--bordered">
                <h2>AUTRES ARTICLES</h2>
            </div>
            <div class="product-slider sb-slick-slider slider-border-single-row" data-slick-setting='{
        "autoplay": true,
        "autoplaySpeed": 8000,
        "slidesToShow": 4,
        "dots":true
    }' data-slick-responsive='[
        {"breakpoint":1200, "settings": {"slidesToShow": 4} },
        {"breakpoint":992, "settings": {"slidesToShow": 3} },
        {"breakpoint":768, "settings": {"slidesToShow": 2} },
        {"breakpoint":480, "settings": {"slidesToShow": 1} }
    ]'>
    <?php $__currentLoopData = \App\Models\Produits::where('enabled',1)->where('quantite','>',0)->inRandomOrder()->take(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="single-slide">
    <div class="product-card">

        <div class="product-card--body">
            <?php $liens=$produit->image; $lien=$liens; $img="img.jpg";
                        if ($lien) { foreach($lien as $i){$img=$i;break; }}
                        if(file_exists(public_path().'/storage/'.$img)) $url=asset('storage/'.$img);
                        else $url=asset('images/articles/noavailable.png')

                        ?>
                                        <div class="card-image" style="height:250px;background-image: url(<?php echo e($url); ?>);background-size:contain; background-position:center;background-repeat:no-repeat">


                <div class="hover-contents">

                    <div class="hover-btns">
                        <a href="cart.html" class="single-btn">
                            <i class="fas fa-shopping-basket"></i>
                        </a>
                        

                        <a href="#" data-toggle="modal" data-target="#quickModal" class="single-btn">
                            <i class="fas fa-eye"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="product-header mt-2 mb-0">

                <h3 class="text-truncate text-capitalize"><a href="<?php echo e(route('produits.show',$produit->code)); ?>"><?php echo e($produit->nom); ?></a>
                </h3>
            </div>
            <div class="price-block" style="margin-top: -20px">
                <span class="price"><?php echo e($produit->prix_vente); ?> fcfa</span>
                <!--<del class="price-old"><?php echo e($produit->prix_achat); ?> fcfa</del>-->
                <!--<span class="price-discount">20%</span>-->
            </div>

        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
        (function ($) {
            "use strict"


            /////////////////////////////////////////

            // Product Main img Slick
            $('#product-main-img').slick({
                infinite: true,
                speed: 300,
                dots: false,
                arrows: true,
                fade: true,
                asNavFor: '#product-imgs',
            });

            // Product imgs Slick
            $('#product-imgs').slick({
                slidesToShow: 3,
                slidesToScroll: 1,
                arrows: true,
                centerMode: true,
                focusOnSelect: true,
                centerPadding: 0,
                vertical: true,
                asNavFor: '#product-main-img',
                responsive: [{
                    breakpoint: 991,
                    settings: {
                        vertical: false,
                        arrows: false,
                        dots: true,
                    }
                },
                ]
            });
        })(jQuery);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/cpanel-disk-a/martheet/public_html/resources/views/produits/detail.blade.php ENDPATH**/ ?>