<?php $__env->startSection('title','Service client | martheetmarie CI'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mb-5">
        <div class="border border-top-0 border-left-0 border-right-0 border-dark mt-5">
            <h3 class="text-center">Puis-je contacter le service client par téléphone ?</h3>
        </div>
        <div class="pt-5">
            <?php $liens= DB::table('settings')->get(); ?>
            <div class="text-left">
                <p class="font-weight-normal">
                    
                    Vous pouvez nous joindre au (+225) <span class="font-weight-bolder"><?php echo e($liens[4]->value); ?></span> 7j/7, entre 8H00 et 17H00 (heure GMT).
                    <br>
                    ou par mail : <?php echo e($liens[5]->value); ?>  <br>
                    Nous sommes également disponibles sur facebook et par whatsapp.
                </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/cpanel-disk-a/martheet/public_html/resources/views/static/contact.blade.php ENDPATH**/ ?>