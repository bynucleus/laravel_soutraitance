<!-- This file is used to store topbar (right) items -->



<?php /**PATH C:\Users\emman\biscrem\Coding Universe\Projects\www\livre\resources\views/vendor/backpack/base/inc/topbar_right_content.blade.php ENDPATH**/ ?>