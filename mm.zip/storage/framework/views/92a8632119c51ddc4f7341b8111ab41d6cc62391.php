<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="author" content="unknow-teams" />
  <meta name="description" content="Marthe & Marie | vente et Location de livres" />
  <meta name="keywords" content="telephonie,tablettes,accessoires,montres,tv,audio," />
  <meta name="robots" content="INDEX,FOLLOW" />

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo $__env->yieldContent('title','Marthe & Marie| vente et Location de livres.'); ?></title>

  
  <!-- Favicon -->
  <link rel="icon" type="image/png" href="images/favicon.png">
  <!-- Web Font -->
  <link
    href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap"
    rel="stylesheet">

  <!-- StyleSheet -->
  <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('css/plugins.css')); ?>" />
  <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('css/main.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('packages/noty/noty.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/css/noty_theme.css')); ?>">

  <?php echo $__env->yieldContent('extra-css'); ?>

</head>
<style>
  body {
    font-family:sp;
    font-size:18px;
  }
  @font-face {
  font-family:"sp";
  src: url("fonts/TenorSans-Regular.ttf") format("truetype");
}
</style>
<body>
  <div class="site-wrapper cover blur-in" id="top">
    <?php echo $__env->make('layouts.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

  </div>
  <hr>
  <?php
  $message = \DB::table('messages')->get()->where('activer',1)->first();
  ?>
  <?php if($message): ?>
  <div class="marquee-rtl">
    <div>
      <a href="<?php echo e($message->lien); ?>" _target='blank'>
        <?php echo $message->message; ?> </a>.</div>
      </div>
      
<?php endif; ?>
  <style>
    .marquee-rtl {
      position: fixed;
      left: 0;
      bottom: 0;
      width: 100%;
      max-height: 40px;
      overflow: hidden;
      /* important */

      /* margin: 2em auto; */
      border: 2px solid #F0F0FF;
      box-shadow: 0 .25em .5em #CCC, inset 0 0 1em .25em #CCC;
      background-color: #eee;
      z-index: 1555;

    }

    .marquee-rtl>div {
      font-size: 1em;
    }

    .marquee-rtl>div {
      display: inline-block;
      /* important */
      white-space: nowrap;
      /* important */
      animation: defilement-rtl 30s infinite linear;
      /* défilement */
      cursor: pointer;
      padding: 5px 1em 5px 50%;
    }

    .marquee-rtl:hover>div {
      animation-play-state: paused;
      /* met en pause le défilement */
    }

    .marquee-rtl>div:first-letter {
      font-weight: 700;
      color: #EE008C;
    }

    @keyframes  defilement-rtl {
      0% {
        -webkit-transform: translate(0);
        transform: translate(0);
      }

      100% {
        -webkit-transform: translate(-100%);
        transform: translate(-100%);
      }
    }
  </style>
  <?php echo $__env->make('layouts.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <!-- COMMON SCRIPTS -->
  <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
  <script src="js/ajax-mail.js"></script>

  <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

  <script src="<?php echo e(asset('library/tiny-slider/tiny-slider.js')); ?>"></script>
  <script src="js/isotope.min.js"></script>
  <script>
    // Isotope filter
		$(window).on('load',function(){
		  var $container = $('.isotope-wrapper');
		  $container.isotope({ itemSelector: '.isotope-item', layoutMode: 'masonry' });
		});
		$('.isotope_filter').on( 'click', 'a', 'change', function(){
		  var selector = $(this).attr('data-filter');
		  $('.isotope-wrapper').isotope({ filter: selector });
		});
  </script>
  
  <script src="<?php echo e(asset('packages/noty/noty.js')); ?>"></script>

  <?php if(Session::has('alerte')): ?>

  <script type="text/javascript">
    Noty.overrideDefaults({
            layout: 'topRight',
            theme: 'backstrap',
            timeout: 2500,
            closeWith: ['click', 'button'],
        });

        new Noty({
            type: "<?php echo e(Session::get('type')); ?>",
            text: "<?php echo str_replace('"', "'", Session::get('alerte')); ?>"
        }).show();

  </script>

  <?php endif; ?>

  <?php echo $__env->yieldContent('extra-js'); ?>
</body>

</html><?php /**PATH C:\Users\emman\biscrem\Coding Universe\Projects\www\livre\resources\views/layouts/app.blade.php ENDPATH**/ ?>