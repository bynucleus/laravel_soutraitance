<?php $__env->startSection('title','votre panier'); ?>
<?php $__env->startSection('extra-meta'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Cart::count()>0): ?>
        
        <section class="section-content d-none d-lg-block bg padding-y border-top">
            <div class="container" style=" margin-top:80px;">
                <center>
                    <p class="h3" style="color: #888;font-weight:bold;">VOTRE PANIER ( <?php echo e(Cart::count()); ?> )</p>
                </center>
                <br>

                <div class="row">
                    <main class="col-sm-9">

                        <div class="card">
                            <table class="table table-hover shopping-cart-wrap">
                                <thead class="text-muted">
                                <tr>
                                    <th scope="col" width="1"></th>

                                    <th scope="col" width="80">IMAGE</th>
                                    <th scope="col" width="150">PRODUIT</th>
                                    <th scope="col" width="150">PRIX</th>
                                    <th scope="col" width="100">QUANTITE</th>
                                    <th scope="col" width="150" class="text-right">TOTAL</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-right" >

                                            <form style="border:none" class=" mt-3"
                                                  action="<?php echo e(route('cart.supprime',$produit->rowId)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input name="produit_id" type="hidden"
                                                       value="<?php echo e($produit->model->code); ?>">
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-outline-danger" style="width:0px">×</button>
                                            </form>
                                        </td>
                                        <td>
                                            <?php  $liens=$produit->model->image; $lien=$liens; $img="img.jpg"; ;
                if ($lien) { foreach($lien as $i){$img=$i;break;} }  ?>
                                            <div class="img-wrap"><img src="<?php echo e(asset('storage/'.$img)); ?>"
                                                                       class="img-thumbnail img-sm" width="100"></div>

                                        </td>

                                        <td>
                                            <h6 class="title text-truncate mt-4" style="font-size: 20px;text-transform:lowercase;width:200px">
                                                <?php echo e($produit->model->nom); ?></h6>


                                        </td>
                                        <td>
                                            <div class="price-wrap mt-4">
                                                <p class="price" style="color:black;font-weight:bold ">
                                                    
                                                    <?php echo e($produit->options['prix']??$produit->model->prix_vente); ?> FCFA</P>

                                            </div>
                                        </td>
                                        <td>

                                            <input type="hidden" id="max_qty" name="max_qty"
                                                   value="<?php echo e($produit->model->quantite); ?>">

                                            <div class="mt-2 border rounded border-color-1 p-1"
                                                 style="width: 80px;">
                                                
                                                     <div class="col-auto">
                                                       

                                                    </div> 
                                                    <div class="row">
                                                        
                                                         <a class="col-5"
                                                           href="<?php echo e(url('/panier/update/'.$produit->model->quantite.'/'.$produit->rowId.'/'.($produit->qty-1))); ?>">
                                                            <small class="fas fa-minus btn-icon__inner"></small>
                                                        </a>
                                                        <input name="qty" id="qty" data-id="<?php echo e($produit->rowId); ?>"
                                                        style="background-color:transparent"
                                                        class="js-result form-control h-auto border-0 rounded p-0 shadow-none col-2"
                                                        type="text" value="<?php echo e($produit->qty); ?>">
                                                        <a class="col-1"
                                                           href="<?php echo e(url('panier/update/'.$produit->model->quantite.'/'.$produit->rowId.'/'.($produit->qty+1))); ?>">
                                                            <small class="fas fa-plus btn-icon__inner"></small>
                                                        </a>
                                                    </div>
                                                
                                            </div>

                                        </td>
                                        <td>
                                            <div class="price-wrap mt-4">

                                                <p class="price text-right"
                                                   style="color:black;font-weight:bold "><?php echo e($produit->subtotal()); ?>

                                                    FCFA</p>

                                            </div> <!-- price-wrap .// -->
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                            <div class="card-body border-top">
                                <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-light float-md-right"
                                   style="font-weight:bold;font-size:18px"> Finaliser la commande &nbsp;<i
                                            class="fa fa-chevron-right" style="color: #002687"></i> </a>
                                <a href="<?php echo e(route('produits.index')); ?>" class="btn btn-light"
                                   style="font-weight:bold;font-size:18px"> <i class="fa fa-chevron-left"
                                                                               style="color: #002687"></i> &nbsp;Continuer
                                    ses achats </a>
                            </div>
                        </div> <!-- card.// -->
                        
                    </main> <!-- col.// -->
                    <aside class="col-md-3">

                        <div class="card">
                            <div class="card-body">
                                <dl class="row row-cols-2">
                                    <dt class="text-left">SOUS TOTAL :</dt>
                                    <dd class="text-right"
                                        style="width:55%;margin-left:-20px;font-weight:bold;color: #000"><?php echo e((Cart::subtotal())); ?>

                                        Fcfa
                                    </dd>
                                </dl>

                                <dl class="row row-cols-2 dlist-align">
                                    <dt class="text-left">TOTAL :</dt>
                                    <dd class="text-right"
                                        style="width:55%;margin-left:-20px;font-weight:bold;color: #EE008C"><?php echo e(Cart::total()); ?>

                                        Fcfa
                                    </dd>
                                </dl>

                                <hr>


                            </div> <!-- card-body.// -->
                        </div>  <!-- card .// -->
                    </aside>
                </div>

            </div> <!-- container .//  -->
        </section>
        <section class="section-content d-block d-lg-none bg padding-y border-top">
            <div class="container" style=" margin-top:50px;">
                <a href="<?php echo e(route('produits.index')); ?>" style="color:#000;font-size:18px"><span><i
                                class="fa fa-arrow-left float-left mt-2"></i></span></a>

                <center><p class="h5" style="color: #888;font-weight:bold;">VOTRE PANIER ( <?php echo e(Cart::count()); ?> )</p>
                </center>
                <br>

                <main class="col-sm-9">
                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-3" style="box-shadow: 0px 0px 5px 0px rgba(46, 41, 41, 0.192);">

                            <figure class="media p-2">
                                <?php  $liens=$produit->model->image; $lien=$liens; $img="img.jpg";
                    if ($lien) { foreach($lien as $i){$img=$i;break;} } ?>
                                <div class="img-wrap"><img src="<?php echo e(asset('storage/'.$img)); ?>"
                                                           style="border:none;width:100%;height:150px"
                                                           class="img-thumbnail img-sm"></div>
                                <figcaption class="media-body text-center">
                                   
                                    <h6 class="title text-truncate mt-2 word-limit"
                                        style="color: black;font-size:20px;width :150px;text-transform:lowercase;"><?php echo e($produit->model->nom); ?></h6>

                                    <span style="color: #002687;font-weight:bold;font-size:17px"><?php echo e(getprice($produit->model->prix_vente)); ?> </span>F
                                    <del class="price-old"><?php echo e(getprice($produit->model->prix_achat)); ?> F</del>

                                </figcaption>
                            </figure>
                            <div class="card-body border-top">
                                <div class="row row-cols-2">

                                    <div class="col">
                                        <form style="border: none;margin:0"
                                              action="<?php echo e(route('cart.supprime',$produit->rowId)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-outline-danger" style="width:5px"><i
                                                        class="fa fa-trash text-danger" style="font-size: 20px"></i>
                                            </button>
                                        </form>
                                    </div>
                                    <div class="col" style="background: olie;margin-left:-10%">
                                        <input type="hidden" id="max_qty" name="max_qty"
                                               value="<?php echo e($produit->model->quantite); ?>">
                                               <div class="mt-2 border rounded border-color-1 p-1"
                                               style="width: 80px;">
                                              
                                                   <div class="col-auto">
                                                     

                                                  </div> 
                                                  <div class="row">
                                                      
                                                       <a class="col-5"
                                                         href="<?php echo e(url('/panier/update/'.$produit->model->quantite.'/'.$produit->rowId.'/'.($produit->qty-1))); ?>">
                                                          <small class="fas fa-minus btn-icon__inner"></small>
                                                      </a>
                                                      <input name="qty" id="qty" data-id="<?php echo e($produit->rowId); ?>"
                                                      style="background-color:transparent"
                                                      class="js-result form-control h-auto border-0 rounded p-0 shadow-none col-2"
                                                      type="text" value="<?php echo e($produit->qty); ?>">
                                                      <a class="col-1"
                                                         href="<?php echo e(url('panier/update/'.$produit->model->quantite.'/'.$produit->rowId.'/'.($produit->qty+1))); ?>">
                                                          <small class="fas fa-plus btn-icon__inner"></small>
                                                      </a>
                                                  </div>
                                              
                                          </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </main>

            </div>
        </section>
        <hr>
        <section class="mb-4 d-lg-none">

            <div class="mt-3 col-sm-12" style="background: white">

                <center style="font-size: 18px">
                    <span class="text-left" style="font-weight: bold">sous total :</span>
                    <span class="text-right" style="font-weight: bold;color:black"><?php echo e((Cart::subtotal())); ?></span> Fcfa
                </center>

                <center style="font-size: 18px">
                    <span class="text-left" style="font-weight: bold">Total :</span>
                    <span class="text-right" style="font-weight: bold;color:#EE008C"><?php echo e(($total)); ?></span> Fcfa
                </center>


                <center class="mt-2">
                    <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-outline-dark "
                       style="font-weight:bold;font-size:18px;">
                        Finaliser la commande &nbsp;<i class="fa fa-chevron-right" style="color: #EE008C"></i> </a>
                    <a href="<?php echo e(route('produits.index')); ?>" class="btn btn-outline-dark mt-2"
                       style="font-weight:bold;font-size:18px;">
                        <i class="fa fa-chevron-left" style="color: #EE008C"></i> &nbsp;Continuer ses achats </a>
                </center>
            </div>
        </section>
    <?php else: ?>
        <section class="section-content bg padding-y border-top" style="height: 60vh">
            <div class="container" style=" margin-top:100px;">

                <center><p class="h3" style="font-weight:bold;">VOTRE PANIER EST VIDE</p><br>
                    <p>ajouter des produits dans votre panier</p>
                    <div class="col-md-6 mt-4 ">
                        <a href="<?php echo e(route('produits.index')); ?>" class="btn rounded-0 btn-outline-dark btn-lg btn-block"
                           type="button" style="">passez aux achats !</a>
                    </div>
                </center>
            </div>
        </section>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>

        function plus(s) {
            var v = document.getElementById("qty");
            var q = parseInt(v.value) + 1;
            v.value = q;
        }

        function moins(s) {
            var v = document.getElementById("qty");
            var q = parseInt(v.value) - 1;
            v.value = q;
        }

    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/cpanel-disk-a/martheet/public_html/resources/views/panier/index.blade.php ENDPATH**/ ?>