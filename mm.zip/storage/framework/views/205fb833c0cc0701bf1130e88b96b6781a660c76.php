<section class="hero-area hero-slider-4 ">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 offset-lg-3">
                <div class="sb-slick-slider" data-slick-setting='{
                    "autoplay": true,
                    "autoplaySpeed": 5000,
                    "slidesToShow": 1,
                    "dots":true
                                     }'>

                     <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($i%2!=0): ?>
                     <a href="<?php echo e($slide->url); ?>">
                     <div class="single-slide bg-image" data-bg="<?php echo e(asset($slide->nom)); ?>">
                        <div class="home-content text-left pl--30">
                            <div class="row">
                                <div class="col-lg-5">
                                    
                                    <h3 class="title-small"><?php echo e($slide->titre); ?></h3>
                                    <p style="font-size:25px;color:white"><?php echo e($slide->texte); ?>

                                       </p>


                                </div>
                            </div>
                        </div>
                    </div>
                    </a>
                     <?php else: ?>
                     <a href="<?php echo e($slide->url); ?>">
                        <?php if(!$slide->titre): ?>

                        <div class="single-slide bg-image" data-bg="<?php echo e(asset($slide->nom)); ?>">
                        <?php else: ?>

                        <div class="single-slide bg-image bg-overlay--dark" data-bg="<?php echo e(asset($slide->nom)); ?>">
                        <?php endif; ?>
                        <div class="home-content text-center">
                            <div class="row justify-content-end">
                                <div class="col-lg-8">
                                    <h1 class="v2"><?php echo e($slide->titre); ?></h1>
                                    <h2><?php echo e($slide->texte); ?></h2>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                     </a>
                     <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /opt/cpanel-disk-a/martheet/public_html/resources/views/layouts/partial/slide.blade.php ENDPATH**/ ?>