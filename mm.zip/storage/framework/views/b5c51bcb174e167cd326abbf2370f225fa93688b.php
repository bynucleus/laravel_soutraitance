
<?php $__env->startSection('title','connexion'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container-fluid mt-5 mb-5">
        <div class="row justify-content-center">
            <?php if(isset($message) && !empty($message)): ?>
                <div class="col-12 col-lg-6 text-center">
                    <i class="fa fa-check-circle fa-5x text-center text-success" aria-hidden="true"></i>
                    <h3 class="text-success text-center"><?php echo e($message); ?></h3>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/cpanel-disk-a/martheet/public_html/resources/views/message.blade.php ENDPATH**/ ?>