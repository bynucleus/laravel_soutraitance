
<?php $__env->startSection('title'); ?>
    Page not found.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <div class="col-12">
            <div class="">
                <div class="text-center">
                    <h5>ERREUR 404</h5>
                    <p class="display-4">PAGE NOT FOUND</p>
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-outline-dark">retourner sur la page d'accueil</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/cpanel-disk-a/martheet/public_html/resources/views/errors/404.blade.php ENDPATH**/ ?>