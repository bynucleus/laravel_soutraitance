<table class='table order-details-table'>
                                        <thead>
                                            <tr>
                                                <th>Produit</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                               
                                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $produit=\DB::table('produits')->where('code',$article->code_prod)->first() ?>
                                            <tr>
                                            <td><a href='<?php echo e(route('produits.show',$produit->code)); ?>' class="text-truncate text-capitalize word-limit" style="max-width:250px"><?php echo e($produit->nom); ?></a>
                                                <strong>× <?php echo e($article->quantite); ?></strong></td>
                                            <td><span><?php echo e($article->prix_vente); ?></span></td>
                                        </tr>
                                        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <?php
                                        $livraison = $commande->prix_livraison??0;
                                        ?>
                                        <tfoot>
                                            <tr>
                                                <th>Sous total:</th>
                                                <td><span><?php echo e($commande->montant-$livraison); ?></span></td>
                                            </tr>
                                            <?php if($livraison!=0): ?>
                                            <tr>
                                                <th>Prix Livraison:</th>
                                                <td><?php echo e($livraison); ?></td>
                                            </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <th>Total:</th>
                                                <td><span><?php echo e($commande->montant); ?></span></td>
                                            </tr>
                                        </tfoot>
                                    </table>
<?php /**PATH /opt/cpanel-disk-a/martheet/public_html/resources/views/client/detailcommande.blade.php ENDPATH**/ ?>