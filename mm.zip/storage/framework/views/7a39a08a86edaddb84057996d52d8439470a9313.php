<footer class="site-footer">
    <?php
    $numero = DB::table('settings')->where('key', 'contact_1')->first()->value; 
    $email = DB::table('settings')->where('key', 'email')->first()->value;
    $facebook = DB::table('settings')->where('key', 'facebook_page')->first()->value;
    $youtube = DB::table('settings')->where('key', 'youtube_page')->first()->value;
?>
    <div class="container">
        <div class="row justify-content-between  section-padding">
            <div class=" col-xl-3 col-lg-4 col-sm-6">
                <div class="single-footer pb--40">
                    <div class="brand-footer footer-title">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" height="100" alt="">
                    </div>
                    <div class="footer-contact">
                        
                        <p><span class="label">Téléphone:</span><span class="text"><?php echo e($numero); ?></span></p>
                        <p><span class="label">Email:</span><span class="text" style="font-size:15px;"><?php echo e($email); ?></span></p>
                    </div>
                </div>
            </div>
            <div class=" col-xl-3 col-lg-2 col-sm-6">
                <div class="single-footer pb--40">
                    <div class="footer-title">
                        <h3>Information</h3>
                    </div>
                    <ul class="footer-list normal-list">
                        <li><a href="<?php echo e(url('apropos')); ?>">A propos de nous</a></li>
                        <li><a href="<?php echo e(url('conditions')); ?>">Condition générale d'utilisation</a></li>
                        <li><a href="<?php echo e(url('confidentialite')); ?>">Politique de confidentialité</a></li>
                   
                    </ul>
                </div>
            </div>
            <div class=" col-xl-3 col-lg-2 col-sm-6">
                <div class="single-footer pb--40">
                    <div class="footer-title">
                        <h3>Extras</h3>
                    </div>
                    <ul class="footer-list normal-list">
                        <li><a href="<?php echo e(url('mon-compte')); ?>">Mon compte</a></li>
                        <li><a href="<?php echo e(url('produits')); ?>">Boutique</a></li>
                        <li><a href="<?php echo e(url('contact')); ?>">Nous contacter</a></li>
        
                    </ul>
                </div>
            </div>
            <div class=" col-xl-3 col-lg-4 col-sm-6">
                <div class="footer-title">
                    <h3>SOCIAL</h3>
                </div>
                
                <div class="social-block">
                    
                    <ul class="social-list list-inline">
                        <li class="single-social facebook"><a href="<?php echo e($facebook); ?>" target="_blank"><i class="ion ion-social-facebook"></i></a>
                        </li>
                        <li class="single-social whatsapp bg-dark"><a href="https://wa.me/225<?php echo e($numero); ?>?text=Hello Martheetmarie.com" target="_blank"><i class="fab fa-whatsapp"></i></a></li>
                        
                        <li class="single-social youtube"><a href="<?php echo e($youtube); ?>" target="_blank"><i class="ion ion-social-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            
            <a href="#" class="payment-block">
                
            </a>
            <p class="copyright-text">Copyright © 2021 <a href="" class="author">Marthe & Marie</a>. Tout droit reservé.
                <br>
                Design By <a href="http://sminth.atwebpages.com/" target="_blank" rel="noopener noreferrer" class="author">Sminth</a></p>
        </div>
    </div>
</footer><?php /**PATH C:\Users\emman\biscrem\Coding Universe\Projects\www\livre\resources\views/layouts/partial/footer.blade.php ENDPATH**/ ?>