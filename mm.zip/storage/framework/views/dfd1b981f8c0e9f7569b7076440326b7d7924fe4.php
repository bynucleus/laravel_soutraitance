
<?php $__env->startSection('title','connexion'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid mt-5 mb-5">
    <div class="row justify-content-center">
        <form action="<?php echo e(route('request-password')); ?>" method="post" class="col-11 col-md-5">
            <?php echo e(csrf_field()); ?>

            <div class="form-body">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label for="password">demande de restauration du mot de passe</label>
                            <input name="email" type="email"  maxlength="50" required>
                            <?php if($errors->has('email')): ?>
                                <p class="text-danger "><?php echo e($errors->first('password')); ?></p>
                            <?php endif; ?>
                        </div>
                            
                        <div class="form-group">
                            <div class="row align-items-center mb-2">
                                <div class="col-12 ">
                                    <button type="submit" class="btn btn-block btn-register">confirmer</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>

        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/cpanel-disk-a/martheet/public_html/resources/views/auth/forgotpassword.blade.php ENDPATH**/ ?>