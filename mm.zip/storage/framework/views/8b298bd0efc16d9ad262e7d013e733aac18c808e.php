<?php $__env->startSection('title','nos produits'); ?>
<?php $__env->startSection('content'); ?>
<section class="breadcrumb-section">
    <h2 class="sr-only">Site </h2>
    <div class="container">
        <div class="breadcrumb-contents">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(URL('/')); ?>">Accueil</a></li>
                    <?php if(!isset($categorie)): ?> <li class="breadcrumb-item active"><a href="<?php echo e(URL('/produits')); ?>">Boutique</a></li>
                    <?php else: ?>
                    <?php $__currentLoopData = $lien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item=>$i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($item==$categorie->nom): ?>
                            <li class="breadcrumb-item active"><a

                                        href="<?php echo e(route($i,['categorie'=>$categorie->code])); ?>"><?php echo e($item); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="breadcrumb-item"><a href="#"><?php echo e($item); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                </ol>
            </nav>
        </div>
    </div>
</section>
<main class="inner-page-sec-padding-bottom">
    <div class="container">
        <div class="shop-toolbar mb--30">
            <div class="row align-items-center">
                <div class="col-lg-2 col-md-2 col-sm-6">
                    <!-- Product View Mode -->
                    <div class="product-view-mode">
                        <a href="#" class="sorting-btn active" data-target="grid"><i class="fas fa-th"></i></a>
                        <a href="#" class="sorting-btn" data-target="grid-four">
                            <span class="grid-four-icon">
                                <i class="fas fa-grip-vertical"></i><i class="fas fa-grip-vertical"></i>
                            </span>
                        </a>
                        <a href="#" class="sorting-btn" data-target="list "><i class="fas fa-list"></i></a>
                    </div>
                </div>
                <div class="col-xl-5 col-md-4 col-sm-6  mt--10 mt-sm--0">
                    <span class="toolbar-status">
                        <?php echo e(count($produits)); ?> produits trouvés
                    </span>
                </div>

                <div class="col-xl-4 col-lg-5 col-md-5 col-sm-7 mt--10 mt-md--0 ">
                    <div class="sorting-selection">
                        <span>filtre sur le prix:</span>
                        <?php $code_categorie=request()->categorie; ?>
                        <form style="border: none" action="<?php echo e(route('produits.index')); ?>" method="GET">
                            <select onchange='this.form.submit()' name='trie'
                                class="form-control nice-select sort-select mr-0">
                                <option value="0" selected="selected">Aucun filtre</option>
                                <option value="1">prix croissant</option>
                                <option value="2">prix decroissant</option>
                            </select>
                            <input type="hidden" name="categorie" value="<?php echo e($code_categorie); ?>">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="shop-toolbar d-none">
            <div class="row align-items-center">
                <div class="col-lg-2 col-md-2 col-sm-6">
                    <!-- Product View Mode -->
                    <div class="product-view-mode">
                        <a href="#" class="sorting-btn active" data-target="grid"><i class="fas fa-th"></i></a>
                        <a href="#" class="sorting-btn" data-target="grid-four">
                            <span class="grid-four-icon">
                                <i class="fas fa-grip-vertical"></i><i class="fas fa-grip-vertical"></i>
                            </span>
                        </a>
                        <a href="#" class="sorting-btn" data-target="list "><i class="fas fa-list"></i></a>
                    </div>
                </div>
                <div class="col-xl-5 col-md-4 col-sm-6  mt--10 mt-sm--0">
                    <span class="toolbar-status">
                        <?php echo e(count($produits)); ?> produits trouvés
                    </span>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-6  mt--10 mt-md--0">

                </div>
                <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 mt--10 mt-md--0 ">
                    <div class="sorting-selection">
                        <span>filtre sur le prix:</span>
                        <?php $code_categorie=request()->categorie; ?>
                        <form style="border: none" action="<?php echo e(route('produits.index')); ?>" method="GET">
                            <select onchange='this.form.submit()' name='trie'
                                class="form-control nice-select sort-select mr-0">

                            </select>
                            <input type="hidden" name="categorie" value="<?php echo e($code_categorie); ?>">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="shop-product-wrap grid with-pagination row space-db--30 shop-border">
            <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $liens=$produit->image; $lien=json_decode($liens); $img="img.jpg";
            if ($lien) { foreach($lien as $i){$img=$i;break;} }
            if(file_exists(public_path().'/storage/'.$img)) $url=asset('storage/'.$img);
            else $url=asset('images/articles/noavailable.png')

            ?>
            <div class="col-lg-4 col-sm-6">
                <div class="product-card">
                    <div class="product-grid-content">


                        <div class="product-card--body">

                            <div class="card-image"
                                style="height:290px;background-image: url(<?php echo e($url); ?>);background-size:contain; background-position:center;background-repeat:no-repeat">
                                
                                <div class="hover-contents">
                                    <a href="<?php echo e(route('produits.show',$produit->code)); ?>" class="hover-image">
												<img src="<?php echo e($url); ?>" alt="" style="width: 60%">
                                    </a>
                                    <div class="hover-btns">
                                        <form  id="form" action="<?php echo e(route('cart.store')); ?>" method="POST" style="border-right:1px solid #eee">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="code_produit" value="<?php echo e($produit->code); ?>">

                                            <button type="submit" class="single-btn">
                                            <i class="fas fa-shopping-basket"></i>
                                            </button>
                                        </form>

                                        

                                        </a>
                                        <a href="<?php echo e(route('produits.show',$produit->code)); ?>" class="single-btn">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="product-header mt-2 mb-0">

                                <h3 class="text-truncate text-capitalize word-limit"><a href="<?php echo e(route('produits.show',$produit->code)); ?>"> <?php echo e($produit->nom); ?></a></h3>
                            </div>
                            <div class="price-block " style="margin-top: -20px">
                                <span class="price"><?php echo e($produit->prix_vente); ?> fcfa</span>

                                <?php
                                    $offre = \DB::table('offres')->where('code_produit',$produit->code)->first();

                                ?>
                                <?php if($offre && intval($offre->reduction)!=0): ?>

                                <del class="price-old"><?php echo e($produit->prix_achat); ?> fcfa</del>
                                <span class="price-discount"><?php echo e($offre->reduction); ?>%</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="product-list-content">
                        <div class="card-image"
                        style="height:280px;width:200px;background-image: url(<?php echo e($url); ?>);background-size:cover; background-position:center;background-repeat:no-repeat">

                            
                        </div>
                        <div class="product-card--body ml-lg-5">
                            
                            <article>
                                
                                
                            </article>
                            <div class="product-header mt-2 mb-0">

                                <h3 class="text-truncate text-capitalize word-limit"><a href="<?php echo e(route('produits.show',$produit->code)); ?>"> <?php echo e($produit->nom); ?></a></h3>
                            </div>
                            <div class="price-block " style="margin-top: -20px">
                                <span class="price"><?php echo e($produit->prix_vente); ?> fcfa</span>
                                
                                
                            </div>
                            
                            <div class="btn-block ">
                                <a href="" class="btn btn-outlined">Ajouter au panier</a>
                                
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <br>
        <!-- Pagination Block -->
        <?php echo e($produits->links()); ?>



    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<script>
    const checkbox = $(".categorie");

        checkbox.change(function (event) {
            var checkbox = event.target;
            // if (checkbox.checked) {
            // alert(checkbox.name);
            // } else {
            //     alert('no');
            // }
            // form = event.target.parentNode;
            // alert(form);
            // node = document.createElement("input");
            // node.name  = "categorie";
            // node.type  = "hidden";
            // node.value = checkbox.name;
            // form.appendChild(node.cloneNode());
            $('#form1').submit();
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emman\biscrem\Coding Universe\Projects\www\livre\resources\views/produits/index.blade.php ENDPATH**/ ?>