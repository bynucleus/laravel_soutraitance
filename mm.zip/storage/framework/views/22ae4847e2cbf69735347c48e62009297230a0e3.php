<div class="site-header header-4 mb--20 d-none d-lg-block">
    <?php
        $numero = DB::table('settings')->where('key', 'contact_2')->first()->value;
        $whatsapp = DB::table('settings')->where('key', 'contact_1')->first()->value;
        $email = DB::table('settings')->where('key', 'email')->first()->value;
        $facebook = DB::table('settings')->where('key', 'facebook_page')->first()->value;
    ?>
        <div class="header-middle pt--10 pb--10">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3">
                        <a href="<?php echo e(route('accueil')); ?>" class="site-brand">
                            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" height="60">
                        </a>
                    </div>
                    <div class="col-lg-5">
                        <div class="header-search-block">
                            <form class="input" action="<?php echo e(route('produits.recherche')); ?>" method="get">
                            <input name="q" type="text" placeholder="Entrez votre recherche">
                            <button style="background-color: #00A19B">Rechercher</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="main-navigation flex-lg-right">
                            <div class="cart-widget">
                                <div class="login-block">
                                    <a href="<?php echo e(route('login.index')); ?>" class="font-weight-bold"><i class="fas fa-user-circle" style="font-size: 25px"></i></a>
                                </div>
                                <div class="">
                                    <a href="<?php echo e(route('cart.index')); ?>" class="font-weight-bold cart-link link-icon"><i class="ion-bag" style="font-size: 25px"></i><span class="" style="font-size: 12px;
                                        background: #00A19B; color: #fff;  padding: 0 5px; border-radius: 50%;vertical-align: top;" ><?php echo e(Cart::count()); ?></span></a>

                                    
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-bottom  <?php if(!Request()->is('/')): ?><?php echo e("bg-primary"); ?> <?php endif; ?>">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3">

                        <nav class="category-nav  <?php if(!Request()->is('/')): ?><?php echo e("white-nav"); ?> <?php endif; ?> <?php if(Request()->is('/')): ?><?php echo e("show"); ?> <?php echo e('primary-nav'); ?> <?php endif; ?>" >
                            <div>
                                <a href="javascript:void(0)" class="category-trigger"><i
                                        class="fa fa-bars"></i>
                                    CATEGORIES</a>
                                <ul class="category-menu" style="border:2px solid #EE008C">


                                    <?php $__currentLoopData = DB::table('categories')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="cat-item"><a href="<?php echo e(url('/produits?categorie='.$item->code)); ?>"><?php echo e($item->nom); ?></a></li>

                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    
                                </ul>
                            </div>
                        </nav>
                    </div>
                    <div class="col-lg-3">
                        <div class="header-phone <?php if(!Request()->is('/')): ?><?php echo e("color-white"); ?> <?php endif; ?>">
                            <div class="icon">
                                <i class="fas fa-headphones-alt"></i>
                            </div>
                            <div class="text">
                                <p>Support 24h/7j</p>
                                <p class="font-weight-bold number"> <?php echo e($numero); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="main-navigation flex-lg-right">
                            <ul class="main-menu menu-right <?php if(!Request()->is('/')): ?><?php echo e("main-menu--white"); ?> <?php endif; ?>   li-last-0">
                                <li class="menu-item">
                                    <a href="<?php echo e(route('accueil')); ?>"><strong>Accueil</strong></a>
                                </li>
                                <!-- Shop -->
                                <li class="menu-item">
                                    <a href="<?php echo e(route('produits.index')); ?>"><strong>Boutique</strong></a>
                                </li>

                                <li class="menu-item">
                                    <a href="#"><strong>Abonnement</strong></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="site-mobile-menu">
        <header class="mobile-header d-block d-lg-none pt--10 pb-md--10">
            <div class="container">
                <div class="row align-items-sm-end align-items-center">
                    <div class="col-md-4 col-7">
                        <a href="<?php echo e(route('accueil')); ?>" class="site-brand">
                            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" height="60">
                        </a>
                    </div>
                    <div class="col-md-5 order-3 order-md-2">
                        <nav class="category-nav   ">
                            <div>
                                <a href="javascript:void(0)" class="category-trigger"><i
                                        class="fa fa-bars"></i>CATEGORIES</a>
                                <ul class="category-menu">
                                    <?php $__currentLoopData = DB::table('categories')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="cat-item"><a href="<?php echo e(url('/produits?categorie='.$item->code)); ?>"><?php echo e($item->nom); ?></a></li>

                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            </div>
                        </nav>
                    </div>
                    <div class="col-md-3 col-5  order-md-3 text-right">
                        <div class="mobile-header-btns header-top-widget">
                            <ul class="header-links">
                                <li class="sin-link">
                                    <a href="<?php echo e(route('cart.index')); ?>" class="cart-link link-icon"><i class="ion-bag"></i><span class="" style="font-size: 12px;
                                        background: #00A19B; color: #fff;  padding: 0 5px; border-radius: 50%;vertical-align: top;"><?php echo e(Cart::count()); ?></span></a>
                                </li>
                                <li class="sin-link">
                                    <a href="javascript:" class="link-icon hamburgur-icon off-canvas-btn"><i
                                            class="ion-navicon"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!--Off Canvas Navigation Start-->
        <aside class="off-canvas-wrapper">
            <div class="btn-close-off-canvas">
                <i class="ion-android-close"></i>
            </div>
            <div class="off-canvas-inner">
                <!-- search box start -->
                <div class="search-box offcanvas">
                    <form class="input" action="<?php echo e(route('produits.recherche')); ?>" method="get">
                        <input name="q" type="text" placeholder="Rechercher içi">
                        <button class="search-btn"><i class="ion-ios-search-strong"></i></button>
                    </form>
                </div>
                <!-- search box end -->
                <!-- mobile menu start -->
                <div class="mobile-navigation">
                    <!-- mobile menu navigation start -->
                    <nav class="off-canvas-nav">
                        <ul class="mobile-menu main-mobile-menu">
                            <li><a href="<?php echo e(route('accueil')); ?>"><strong>Accueil</strong></a> </li>
                            <li> <a href="<?php echo e(route('produits.index')); ?>"><strong>Boutique</strong></a> </li>

                            <li>
                                <a href="<?php echo e(url('/apropos')); ?>"><strong>Qui sommes nous ?</strong></a>
                            </li>
                            <li><a href="#"><strong>Abonnement</strong></a></li>
                        </ul>
                    </nav>
                    <!-- mobile menu navigation end -->
                </div>
                <!-- mobile menu end -->
                <nav class="off-canvas-nav">
                    <ul class="mobile-menu menu-block-2">
                        <?php if(Auth()->user()): ?>
                        <a href="<?php echo e(URL('/mon-compte')); ?>">Mon Compte </a>
                        <?php else: ?>
                        <a href="<?php echo e(URL('/login')); ?>"><strong>Mon Compte</strong></a>
                        <?php endif; ?>

                    </ul>
                </nav>
                <div class="off-canvas-bottom">
                    <div class="contact-list mb--10">
                        <a href="tel://<?php echo e($numero); ?>" class="sin-contact"><i class="fas fa-mobile-alt"></i><?php echo e($numero); ?></a>
                        <a href="mailto:<?php echo e($email); ?>" class="sin-contact"><i class="fas fa-envelope"></i><?php echo e($email); ?></a>
                    </div>
                    <div class="off-canvas-social">
                        <a href="<?php echo e($facebook); ?>" target="_blank" class="single-icon"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://wa.me/225<?php echo e($whatsapp); ?>?text=Hello Martheetmarie.com" target="_blank" class="single-icon"><i class="fab fa-whatsapp"></i></a>

                        

                        

                        
                    </div>
                </div>
            </div>
        </aside>
        <!--Off Canvas Navigation End-->
    </div>
    <div class="sticky-init fixed-header common-sticky">
        <div class="container d-none d-lg-block">
            <div class="row align-items-center">
                <div class="col-lg-4">
                    <a href="<?php echo e(route('accueil')); ?>" class="site-brand">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" height="60">
                    </a>
                </div>
                <div class="col-lg-8">
                    <div class="main-navigation flex-lg-right">
                        <ul class="main-menu menu-right ">
                            <li class="menu-item">
                                <a href="<?php echo e(route('accueil')); ?>"><strong>Accueil</strong></a>
                            </li>
                            <!-- Shop -->
                            <li class="menu-item">
                                <a href="<?php echo e(route('produits.index')); ?>">Boutique</a>
                            </li>

                            <li class="menu-item">
                                <a href="#">Abonnement</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH C:\Users\emman\biscrem\Coding Universe\Projects\www\livre\resources\views/layouts/partial/header.blade.php ENDPATH**/ ?>