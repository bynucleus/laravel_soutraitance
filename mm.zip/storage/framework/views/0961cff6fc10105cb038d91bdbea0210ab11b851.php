<!-- This file is used to store topbar (left) items -->


<?php /**PATH C:\Users\emman\biscrem\Coding Universe\Projects\www\livre\resources\views/vendor/backpack/base/inc/topbar_left_content.blade.php ENDPATH**/ ?>