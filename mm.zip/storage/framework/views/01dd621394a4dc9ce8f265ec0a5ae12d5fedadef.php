<?php $__env->startSection('title','checkout'); ?>
<?php $__env->startSection('content'); ?>

<section class="breadcrumb-section">
    <h2 class="sr-only">Site Breadcrumb</h2>
    <div class="container">
        <div class="breadcrumb-contents">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Accueil</a></li>
                    <li class="breadcrumb-item active">Checkout</li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<main id="content" class="page-section inner-page-sec-padding-bottom space-db--20">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <!-- Checkout Form s-->
                <div class="checkout-form">
                    <form id="form" action="<?php echo e(route('checkout.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                    <div class="row row-40">
                        <div class="col-12">
                            <h1 class="quick-title">Checkout</h1>
                            <!-- Slide Down Trigger  -->
                            <div class="checkout-quick-box">
                                <p><i class="far fa-sticky-note"></i>Renseignez vos informations</p>
                            </div>
                            <!-- Slide Down Blox ==> Login Box  -->
                            
                            <!-- Slide Down Trigger  -->
                            
                            <!-- Slide Down Blox ==> Cupon Box -->
                            
                        </div>
                        <div class="col-lg-7 mb--20">
                            
                            <!-- Billing Address -->
                            <div id="billing-form" class="mb-40">
                                <h4 class="checkout-title">Information Personnel</h4>
                                <div class="row">
                                    <div class="col-md-6 col-12 mb--20">
                                        <label>Nom*</label>
                                        <input value="<?php echo e($client->nom); ?>" required type="text" id="nom" name="nom" placeholder="Votre Nom">
                                    </div>
                                    <div class="col-md-6 col-12 mb--20">
                                        <label>Prénom*</label>
                                        <input value="<?php echo e($client->prenom); ?>" required id="prenom" name="prenom" type="text" placeholder="Votre Prénom">
                                    </div>
                                   
                                  
                                    <div class="col-md-6 col-12 mb--20">
                                        <label>Téléphone*</label>
                                        <input value="<?php echo e($client->telephone); ?>" required maxlength="12" type="text" id="tel" name="tel" placeholder="Votre Numero">
                                    </div>
                                    <div class="col-12 mb--20">
                                        <label>Addresse de Livraison*</label> <br> 
                                        <label>Commune</label>
                                        <select onchange="change(this.value)" style="width:100%;background-color: #f4f4f4;border: 1px solid transparent;line-height: 23px;
                                        padding: 10px 20px; font-size: 14px; color: #14191e; margin-bottom: 15px;" name="commune" id="commune">
                                            <?php $__currentLoopData = DB::table('communes')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commune): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($commune->nom); ?>"><?php echo e($commune->nom); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select> 
                                        <label>Adresse</label>
                                <input name="adresse" type="text" id="adress" value="" placeholder="koumassi remblais" required>

                                     
                                    </div>
                                   
                                    
                                    <input type="hidden" id="prix_livraison" name="prix_livraison">
                                  
                                </div>
                            </div>
                        
                            
                        </div>
                        <div class="col-lg-5">
                            <div class="row">
                                <!-- Cart Total -->
                                <div class="col-12">
                                    <div class="checkout-cart-total">
                                        <h2 class="checkout-title">VOTRE COMMANDE</h2>
                                        <h4>Articles <span>Total</span></h4>
                                        <ul>
                                            <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><span class="left"><?php echo e($produit->model->nom); ?> X <?php echo e($produit->qty); ?></span> <span
                                                    class="right"><?php echo e($produit->total); ?> F</span></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <p>Sous Total <span id="soustotal"><?php echo e(getGoodPrix(Cart::total())); ?></span></p>
                                        <p>Livraison <span id="c_livraison"></span></p>
                                        <h4>Total <span id="total"></span></h4>
                                        <script>
                                       prix_livraison =1000;
                                       document.getElementById('prix_livraison').value=prix_livraison;
                                        document.getElementById('c_livraison').innerText=prix_livraison;
                                        document.getElementById('total').innerText=parseInt(document.getElementById('soustotal').innerText)+prix_livraison + " F";
                                        //    console.log(prix_livraison);
                                       function change(val){
                                           if(val.toLowerCase()!="cocody") prix_livraison =1500;
                                           else prix_livraison =1000;
                                           document.getElementById('prix_livraison').value=prix_livraison;
                                           document.getElementById('c_livraison').innerText=prix_livraison;
                                        document.getElementById('total').innerText=parseInt(document.getElementById('soustotal').innerText)+prix_livraison + " F";

                                        //    console.log(document.getElementById('livraison').value);
                                       }
                                   </script>
                                        <div class="method-notice mt--25">
                                            paiement à la livraison
                                            
                                        </div>
                                        
                                        <button class="place-order w-100 btn btn--primary">confirmer la commande</button> <br>
                                        <a href="/produits" class="w-100 btn btn-outline-dark">annuler</a>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/cpanel-disk-a/martheet/public_html/resources/views/checkout/index.blade.php ENDPATH**/ ?>