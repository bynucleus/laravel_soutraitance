<?php

use Illuminate\Database\Seeder;

class BonReductionsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('bon_reductions')->delete();
        
        
        
    }
}