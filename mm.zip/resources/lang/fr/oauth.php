<?php

return [
    'invalid_credentials' => [ // key from error type
        'error'   => 'Identifiants Incorrects',
        'message' => 'Identifiant ou mot de passe incorrect.'
    ]
];
